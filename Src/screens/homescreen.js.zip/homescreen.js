import React, {useEffect, useState} from 'react';
import {View, Text, TouchableOpacity, Image} from 'react-native';
import colors from '../../Utils/colors';
import metrics from '../../Utils/Metrics';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Entypo from 'react-native-vector-icons/Entypo';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import SwitchToggle from 'react-native-switch-toggle';

const Home = props => {
  const [on, off] = useState(true);
  const [on1, off1] = useState(true);

  // const [getid, setid] = useState(props.route.params.userid);
  useEffect(() => {
    // console.log(getid);
  });
  return (
    <View style={{flex: 1, backgroundColor: colors.white}}>
      <TouchableOpacity
        style={{
          flexDirection: 'row',
          backgroundColor: colors.white,
          height: metrics.HEIGHT * 0.09,
          alignItems: 'center',
          elevation: 5,
          padding: '5%',
        }}
        onPress={() => {
          props.navigation.toggleDrawer();
        }}>
        <Ionicons name="md-menu-sharp" size={30} color={colors.themecolor} />
        <Text
          style={{
            marginLeft: '3%',
            color: colors.themecolor,
            fontSize: 17,
            fontWeight: 'bold',
          }}>
          Dashboard
        </Text>
      </TouchableOpacity>
      <View
        style={{
          flex: 1,
        }}>
        {/* <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginTop: metrics.HEIGHT * 0.02,
            marginHorizontal: '8%',
          }}>
          <Text
            style={{
              color: '#0036BA',
              fontSize: metrics.HEIGHT * 0.03,
              fontWeight: 'bold',
            }}>
            Settings
          </Text>
          <TouchableOpacity>
            <AntDesign name="close" color="#0036BA" size={25} />
          </TouchableOpacity>
        </View> */}

        <View style={{alignSelf: 'center', marginTop: metrics.HEIGHT * 0.04}}>
          <Image
            source={require('../assets/CallSign.png')}
            style={{
              height: metrics.HEIGHT * 0.2,
              width: metrics.WIDTH * 0.4,
              borderRadius: 5,
            }}
            resizeMode="contain"
          />
        </View>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            marginTop: metrics.WIDTH * 0.09,
            marginHorizontal: '8%',
          }}>
          <View style={{flex: 1, height: 0.5, backgroundColor: 'gray'}} />
          <View></View>
        </View>
        <View
          style={{
            marginTop: metrics.HEIGHT * 0.04,
            marginHorizontal: '8%',
            flexDirection: 'row',
            alignItems: 'center',
            alignSelf: 'center',
          }}>
          <Text
            style={{
              color: colors.black,
              fontSize: 16,
            }}>
            App Version :
          </Text>
          <Text style={{color: colors.black, fontSize: 16}}> 2.0</Text>
        </View>
        <View
          style={{
            marginTop: metrics.HEIGHT * 0.02,
            marginHorizontal: '8%',
            flexDirection: 'row',
            alignItems: 'center',
            alignSelf: 'center',
          }}>
          <Text
            style={{
              color: colors.black,
              fontSize: 16,
            }}>
            Device Name :
          </Text>
          <Text style={{color: colors.black, fontSize: 16}}>
            {' '}
            Realme X7 Max
          </Text>
        </View>

        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            marginTop: metrics.WIDTH * 0.09,
            marginHorizontal: '8%',
          }}>
          <View style={{flex: 1, height: 0.5, backgroundColor: 'gray'}} />
          <View></View>
        </View>
        <View
          style={{marginTop: metrics.HEIGHT * 0.04, marginHorizontal: '8%'}}>
          <Text style={{color: colors.black, fontSize: metrics.HEIGHT * 0.025}}>
            Permissions :
          </Text>
          <View
            style={{
              marginTop: metrics.HEIGHT * 0.025,
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}>
            {/* <Text
              style={{color: colors.black, fontSize: metrics.HEIGHT * 0.025}}>
              Camera
            </Text> */}
            <Entypo name="camera" size={25} color={colors.black} />
            <SwitchToggle
              switchOn={on}
              onPress={() => off(!on)}
              circleColorOff={colors.white}
              circleColorOn="#fff"
              backgroundColorOn="#0036BA"
              backgroundColorOff="red"
              textLeftStyle="Right"
              containerStyle={{width: 60, height: 25, borderRadius: 25}}
              circleStyle={{
                width: 20,
                height: 20,
                borderRadius: 14,
                right: on === true ? 3 : -3,
              }}
              backTextRight={on === true ? 'ON' : 'OFF'}
              textRightStyle={{
                color: on === true ? colors.white : colors.white,
                position: 'absolute',
                right: on === true ? -5 : -35,
                bottom: -10,
              }}
            />
          </View>
          <View
            style={{
              marginTop: metrics.HEIGHT * 0.03,
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}>
            {/* <Text
              style={{color: colors.black, fontSize: metrics.HEIGHT * 0.025}}>
              Audio
            </Text> */}
            <FontAwesome name="microphone" size={25} color={colors.black} />
            <SwitchToggle
              switchOn={on1}
              onPress={() => off1(!on1)}
              circleColorOff={colors.white}
              circleColorOn="#fff"
              backgroundColorOn="#0036BA"
              backgroundColorOff="red"
              textLeftStyle="Right"
              containerStyle={{width: 60, height: 25, borderRadius: 25}}
              circleStyle={{
                width: 20,
                height: 20,
                borderRadius: 14,
                right: on1 === true ? 3 : -3,
              }}
              backTextRight={on1 === true ? 'ON' : 'OFF'}
              textRightStyle={{
                color: on1 === true ? colors.white : colors.white,
                position: 'absolute',
                right: on1 === true ? -5 : -35,
                bottom: -10,
              }}
            />
          </View>
        </View>
      </View>
    </View>
  );
};

export default Home;
